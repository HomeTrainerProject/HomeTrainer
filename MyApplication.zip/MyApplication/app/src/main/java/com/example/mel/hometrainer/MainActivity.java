package com.example.mel.hometrainer;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;



public class MainActivity extends Activity {

    EditText percent;
    EditText row;
    EditText percentN2;
    Button validate;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        percent = findViewById(R.id.putPercent);
        percentN2 = findViewById(R.id.putPercent2);
        row = findViewById(R.id.putRow);
        validate = findViewById(R.id.Validation);


        goToProgrammeActivity();
    }

    private void goToProgrammeActivity() {
        validate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    int percentValue = Integer.parseInt(percent.getText().toString());
                    int percentN2Value = Integer.parseInt(percentN2.getText().toString());
                    int rowValue = Integer.parseInt(row.getText().toString());


                    if (percentN2Value == percentValue) {
                        erreurEntree(getString(R.string.errorSame));
                    } else {
                    }

                    if (percentN2Value > 100 || percentValue > 100) {
                        erreurEntree(getString(R.string.error100));
                    } else {
                    }

                    if (rowValue == 0) {
                        erreurEntree(getString(R.string.errorRow));
                    } else {
                    }


                    if (percentValue != percentN2Value && percentValue < 100 && percentN2Value < 100 && rowValue != 0) {

                        Intent intent = new Intent(MainActivity.this, ProgrammeActivity.class);

                        Programme programme = new Programme(percentValue, percentN2Value, rowValue);


                        intent.putExtra("Programme", programme);

                        startActivity(intent);

                    } else {
                    }
                } catch (Exception e) {
                    erreurEntree(getString(R.string.errorEntry));
                }
            }


        });
    }


    private void erreurEntree(String str) {


        AlertDialog error = new AlertDialog.Builder(MainActivity.this).create();
        error.setMessage(str);
        error.setButton(AlertDialog.BUTTON_NEUTRAL, getString(R.string.NeutralResponse), new AlertDialog.OnClickListener() {

            @Override
            public void onClick(DialogInterface dialogInterface, int i) {

            }


        });
        error.show();

    }

}
