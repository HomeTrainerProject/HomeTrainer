package com.example.mel.hometrainer;

import android.app.Activity;

import android.content.Intent;
import android.os.Bundle;

import android.os.CountDownTimer;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.util.Locale;


public class ProgrammeActivity extends Activity {


    private TextView P1;
    private TextView P2;
    private TextView ROW;
    private TextView TIME;
    private TextView tvPercentActual;
    private TextView tvCountDown;
    private Button startPause;
    private Button reset;
    private CountDownTimer mCountDownTimer;
    private CountDownTimer mCountDownInterval;
    private int P1Value;
    private int P2Value;
    private int ROWValue;
    private long TIMEValue;
    int percentActual;

    private boolean mTimerRunning;

    private long start_Time_In_Millis;
    private long mTimeLeftInMillis;
    private long mTimeInterval = 6000;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_programme);

        P1 = (TextView) findViewById(R.id.tvP1);
        P2 = (TextView) findViewById(R.id.tvP2);
        ROW = (TextView) findViewById(R.id.tvRow);
        TIME = (TextView) findViewById(R.id.tvTime);
        tvPercentActual = (TextView) findViewById(R.id.tvPercentActual);
        tvCountDown = (TextView) findViewById(R.id.countDown);
        startPause = (Button) findViewById(R.id.btnStart);
        reset = (Button) findViewById(R.id.btnReset);


        Intent intent = getIntent();
        Programme programme = intent.getParcelableExtra("Programme");
        P1Value = programme.getPourcentage();
        P1.setText("Pourcentage 1 : " + String.valueOf(P1Value));
        P2Value = programme.getPourcentageN2();
        P2.setText("Pourcentage 2 : " + String.valueOf(P2Value));
        ROWValue = programme.getN();
        ROW.setText("Répétitions : " + String.valueOf(ROWValue) + " fois");
        TIMEValue = ROWValue * 5;
        TIME.setText("Durée totale : " + String.valueOf(TIMEValue) + " minutes");


        start_Time_In_Millis = TIMEValue * 60000;
        mTimeLeftInMillis = start_Time_In_Millis;
         percentActual = P1Value;


        startPause.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {



                if (mTimerRunning) {
                    pauseTimer();

                } else {
                    IntervalPercent();
                    startTimer();

                }
            }
        });


        reset.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                resetTimer();

            }
        });
        updateCountDownText();

    }

    private void startTimer() {

        mCountDownTimer = new CountDownTimer(mTimeLeftInMillis, 1000) {
            @Override
            public void onTick(long millisUntilFinished) {
                mTimeLeftInMillis = millisUntilFinished;

                updateCountDownText();

            }

            @Override
            public void onFinish() {
                mTimerRunning = false;
                startPause.setText("Start");
                startPause.setVisibility(View.INVISIBLE);
                reset.setVisibility(View.VISIBLE);

            }

        }.start();

        mTimerRunning = true;
        startPause.setText("Pause");
        reset.setVisibility(View.INVISIBLE);

    }

    private void pauseTimer() {
        mCountDownTimer.cancel();
        mCountDownInterval.cancel();
        mTimerRunning = false;
        startPause.setText("Start");
        reset.setVisibility(View.VISIBLE);
    }

    private void resetTimer() {
        mTimeLeftInMillis = start_Time_In_Millis;
        updateCountDownText();
        resetInterval();
        reset.setVisibility(View.INVISIBLE);
        startPause.setVisibility(View.VISIBLE);


    }

    private void updateCountDownText() {
        int minutes = (int) (mTimeLeftInMillis / 1000) / 60;
        int seconds = (int) (mTimeLeftInMillis / 1000) % 60;

        String timeLeftFormatted = String.format(Locale.getDefault(), "Time left : %02d:%02d", minutes, seconds);

        tvCountDown.setText(timeLeftFormatted);
    }

    private void IntervalPercent(){

        mCountDownInterval = new CountDownTimer(mTimeLeftInMillis, 5000) {
            @Override
            public void onTick(long millisUntilFinished) {
                mTimeLeftInMillis = millisUntilFinished;
                updateInterval();

            }

            @Override
            public void onFinish() {

            }
        }.start();
    }

    private void updateInterval(){

        if(percentActual == P1Value) {
            tvPercentActual.setText(String.valueOf(P1Value));
            percentActual = P2Value;
        } else{
            tvPercentActual.setText(String.valueOf(P2Value));
            percentActual = P1Value;
        }
    }

    private void resetInterval(){
        percentActual = P1Value;
    }


}





