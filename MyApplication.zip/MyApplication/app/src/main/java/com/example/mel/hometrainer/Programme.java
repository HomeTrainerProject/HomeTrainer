package com.example.mel.hometrainer;

import android.os.Parcel;
import android.os.Parcelable;


public class Programme implements Parcelable{
     int n;
     int pourcentageN1;
     int pourcentageN2;


    public Programme( int pourcentageN1, int pourcentageN2,int n) {
        super();
        this.n = n;
        this.pourcentageN1 = pourcentageN1;
        this.pourcentageN2 = pourcentageN2;

    }

    public void setPourcentageN2(int pourcentageN2){
         this.pourcentageN2 = pourcentageN2;
    }

    public int getPourcentageN2() {
        return pourcentageN2;
    }

    public int getN() {
        return n;
    }

    public void setN(int n) {
        this.n = n;
    }

    public int getPourcentage() {
        return pourcentageN1;
    }

    public void setPourcentage(int pourcentage) {
        this.pourcentageN1 = pourcentage;
    }





    @Override
    public int describeContents(){
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {

        dest.writeInt(pourcentageN1);
        dest.writeInt(pourcentageN2);
        dest.writeInt(n);

    }

    public static final Parcelable.Creator<Programme> CREATOR = new Parcelable.Creator<Programme>() {
        @Override
        public Programme createFromParcel(Parcel source) {
            return new Programme(source);
        }

        @Override
        public Programme[] newArray(int size) {
            return new Programme[size];
        }
    };

    public Programme(Parcel source) {
        this.pourcentageN1 = source.readInt();
        this.pourcentageN2 = source.readInt();
        this.n = source.readInt();


    }



    }

